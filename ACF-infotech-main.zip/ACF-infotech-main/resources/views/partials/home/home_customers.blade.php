<section id="hero">
  <div class="container mt-0 mt-lg-5">
    <div class="row">
      <div class="col-md-6 pt-5 pt-lg-0 order-md-1 d-flex flex-column justify-content-center" data-aos="fade-up">
        <div>
          <h1>New way to enjoy quality Products</h1>
          <p>Experience a paradigm shift in the world of computing with our revolutionary laptop sales and services platform. Discover a seamless blend of cutting-edge technology and unparalleled customer care as we redefine your digital experience. Whether you're in search of the latest innovation or expert maintenance and support, our platform offers a new standard of excellence. Embrace convenience, reliability, and innovation as you navigate the realm of laptops with ease. Welcome to a new era of laptop sales and services, where satisfaction meets innovation.</p>
          <a href="#about" class="btn-get-started scrollto">Get Started</a>
        </div>
      </div>
    
    </div>
  </div>

</section>

<main id="main">

  <!-- ======= About Section ======= -->
  <section id="about" class="about">

    <div class="container" data-aos="fade-up">
      <div class="row">

        <div class="col-lg-5 col-md-6 d-none d-md-block">
        </div>

        <div class="col-lg-7 col-md-6">
          <div class="about-content" data-aos="fade-left" data-aos-delay="100">
            <h2>About ACS InfoTech</h2>
            <p>ACS INFOTECH is your premier destination for all your laptop sales and service needs. With a dedication to excellence and a focus on customer satisfaction, we offer a comprehensive range of laptops for sale, ranging from cutting-edge models to budget-friendly options. Our experienced team of professionals is committed to providing top-notch service, including repairs, upgrades, and maintenance, ensuring that your device operates at its peak performance. Whether you're a business professional, a student, or a gaming enthusiast, ACS INFOTECH has the perfect laptop solution for you. Experience unmatched reliability, performance, and support with ACS INFOTECH, your trusted partner in laptop sales and services.</p>
          </div>
        </div>
      </div>
    </div>
  </section>


  <section id="services" class="services section-bg">
    <div class="container">
      <div class="section-title" data-aos="fade-up">
        <h2>Additional Information</h2>
      </div>

      <div class="row">
        <div class="col-md-12 col-lg-6 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="zoom-in">
          <div class="icon-box icon-box-pink">
            <div class="icon"><i class="fa fa-fw fa-dumpster"
                style="font-size: 48px;margin-bottom: 15px;line-height: 1;color:orange;"></i></div>
            <h4 class="title"><a href="">Why ACS INFO Tech?</a></h4>
            <p class="description">Discover the ultimate destination for all your laptop sales and service needs. With ACS INFOTECH, elevate your computing experience to new heights. Whether you're in search of the latest laptop models or expert maintenance and support, we've got you covered. Our dedicated team ensures top-notch service, from repairs and upgrades to personalized recommendations. Experience unmatched reliability and performance with ACS INFOTECH, your trusted partner in the world of laptops.</p>
            <p class="description">Choose ACS INFOTECH for all your laptop sales and service requirements. Rely on our expertise and commitment to excellence to meet your computing needs. Whether you're a business professional, student, or gaming enthusiast, we offer a comprehensive range of laptops and unparalleled support. Embrace innovation and reliability with ACS INFOTECH, where customer satisfaction is our top priority.</p>
                      </div>
                    </div>

        <div class="col-md-12 col-lg-6 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="zoom-in" data-aos-delay="100">
          <div class="icon-box icon-box-cyan">
            <div class="icon"><i class="fa fa-basket-shopping"
                style="font-size: 48px;margin-bottom: 15px;line-height: 1;color:#3fcdc7;"></i></div>
            <h4 class="title"><a href="">Easy way to order!</a></h4>
            <p class="description">Experience the hassle-free way to purchase your next laptop with ACS INFOTECH! Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor suscipit odio, autem quos eos eveniet explicabo perferendis dolore quae cum molestiae itaque nostrum!</p>
            <ul class="description">
              <li>Explore our wide range of laptops tailored to suit your needs.</li>
              <li>Enjoy expert advice and personalized recommendations from our team.</li>
              <li>Experience seamless purchasing and reliable support services.</li>
            </ul>

          </div>
        </div>
      </div>
    </div>
  </section>
</main>